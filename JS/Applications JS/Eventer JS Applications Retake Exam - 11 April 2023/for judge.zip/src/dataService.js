import { api } from "./api.js";

const dataEndpoints = {
    getAll: "data/events?sortBy=_createdOn%20desc",
    getSingle: 'data/events',
}

async function getAllEvents() {
    return api.get(dataEndpoints.getAll)
}

async function getSingleEvent(id) {
    return api.get(dataEndpoints.getSingle + "/" + id)
}

async function createEvent(data) {
    return api.post(dataEndpoints.getSingle, data)
}

async function updateEvent(id, data) {
    return api.put(dataEndpoints.getSingle + "/" + id, data)
}

async function delEvent(id) {
    return api.del(dataEndpoints.getSingle + "/" + id)
}

export const dataService = {
    getAllEvents,
    createEvent,
    getSingleEvent,
    updateEvent,
    delEvent
}