import { html } from "../../node_modules/lit-html/lit-html.js";
import { dataService } from "../dataService.js";
import { userHelper } from "../userHelper.js";

const detailsTemp = (item, isOwner) => html`
    <section id="details">
          <div id="details-wrapper">
            <img id="details-img" src=${item.imageUrl} alt="example1" />
            <p id="details-title">${item.name}</p>
            <p id="details-category">
              Category: <span id="categories">${item.category}</span>
            </p>
            <p id="details-date">
              Date:<span id="date">${item.date}</span></p>
            <div id="info-wrapper">
              <div id="details-description">
                <span>${item.description}</span>
              </div>

            </div>

            <h3>Going: <span id="go">0</span> times.</h3>

            <!--Edit and Delete are only for creator-->
            <div id="action-buttons">
                ${isOwner ? html`
                    <a href="/edit/${item._id}" id="edit-btn">Edit</a>
                    <a @click=${onDelete} href="" id="delete-btn">Delete</a>
                `: html`<a href="" id="go-btn">Going</a>`}
              

              <!--Bonus - Only for logged-in users ( not authors )-->
              
            </div>
          </div>
        </section>
`;

let context = null;
export async function showDetails(ctx) {
    context = ctx;

    const id = ctx.params.id;
    const data  = await dataService.getSingleEvent(id);

    let isOwner = userHelper.getUserID() == data._ownerId;
    ctx.render(detailsTemp(data, isOwner))

    
}

async function onDelete(e) {
    e.preventDefault();

    const id = context.params.id;
    if(window.confirm("are you sure about this?")) {
        await dataService.delEvent(id);
        context.goTo('/catalog');
    }
}