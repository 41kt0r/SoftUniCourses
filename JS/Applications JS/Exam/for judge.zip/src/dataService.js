import { api } from "./api.js";

const dataEndpoints = {
    getAll: "data/characters?sortBy=_createdOn%20desc",
    getSingleForCreate: "data/characters",
    getSingle: "data/characters/",

}

async function getAllCharacters() {
    return api.get(dataEndpoints.getAll)
}

async function createCharacter(data) {
    return api.post(dataEndpoints.getSingleForCreate, data)
}

async function getSingleGeroyche(id) {
    return api.get(dataEndpoints.getSingle + id)
}

async function deleteGeroyche(id) {
    return api.del(dataEndpoints.getSingle + id)
}

async function updateGeroyche(id,data) {
    return api.put(dataEndpoints.getSingle + id, data)
}

export const dataService = {
    getAllCharacters,
    createCharacter,
    getSingleGeroyche,
    deleteGeroyche,
    updateGeroyche
}